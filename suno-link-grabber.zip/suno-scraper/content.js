const RE = /https?:\/\/(?:www\.)?suno\.com\/s\/[A-Za-z0-9_-]+/;
const TAG = '[SunoScraper]';
let running = false, stopFlag = false, waiter = null;

const log = (...a) => console.log(TAG, ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const vis = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
const norm = (s) => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();

async function getLinks() { return (await chrome.storage.local.get('links')).links || []; }
async function setStatus(s) { log(s); await chrome.storage.local.set({ status: s }); }
async function setProgress(done, fail) {
  await chrome.storage.local.set({ progress: { done, fail, total: document.querySelectorAll('.clip-row').length } });
}
async function addLink(url) {
  const links = await getLinks();
  if (!links.includes(url)) { links.push(url); await chrome.storage.local.set({ links }); }
}

// Tangkap link yang di-copy (dari hook.js di konteks halaman)
window.addEventListener('__suno_copy', async (e) => {
  log('copy event:', e.detail);
  const m = String(e.detail).match(RE);
  if (!m) return;
  await addLink(m[0]);
  if (waiter) { waiter(m[0]); waiter = null; }
});

let fetchLinks = [];
window.addEventListener('__suno_fetch', (e) => {
  const m = String(e.detail).match(RE);
  if (m && !fetchLinks.includes(m[0])) fetchLinks.push(m[0]);
});
const watch = (on) => window.dispatchEvent(new CustomEvent('__suno_watch', { detail: on ? 'on' : 'off' }));

function fire(el, types, opts) {
  for (const t of types) {
    const C = t.startsWith('pointer') ? PointerEvent : MouseEvent;
    el.dispatchEvent(new C(t, opts));
  }
}

function hover(el) {
  const r = el.getBoundingClientRect();
  const o = { bubbles: true, cancelable: true, composed: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, pointerId: 1, pointerType: 'mouse', isPrimary: true };
  fire(el, ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove'], o);
}

function realClick(el) {
  const r = el.getBoundingClientRect();
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1, pointerId: 1, pointerType: 'mouse', isPrimary: true };
  hover(el);
  fire(el, ['pointerdown', 'mousedown'], base);
  if (el.focus) try { el.focus({ preventScroll: true }); } catch (e) {}
  fire(el, ['pointerup', 'mouseup', 'click'], { ...base, buttons: 0 });
}

const CLICKABLE = 'button,[role=button],[role=menuitem],a';

// Cari elemen dengan teks persis, paling dalam & terakhir di DOM
function findByText(txt, scope = document) {
  const t = txt.toLowerCase();
  const els = [...scope.querySelectorAll('*')].filter(
    (e) => vis(e) && norm(e.textContent) === t && ![...e.children].some((c) => norm(c.textContent) === t)
  );
  return els.length ? els[els.length - 1] : null;
}

async function waitFor(fn, timeout = 3000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    const v = fn();
    if (v) return v;
    await sleep(100);
  }
  return null;
}

// Baris lagu yang sudah ter-load (placeholder kosong "Untitled" dilewati)
function getRows() {
  const rows = [...document.querySelectorAll('[data-testid="clip-row"]')];
  return rows.map((row) => {
    const a = row.querySelector('a[href^="/song/"]');
    const id = a ? a.getAttribute('href') : null;
    const more = row.querySelector('button[aria-label="More options"]');
    const share = row.querySelector('button[aria-label="Share clip"]');
    return { row, id, more, share };
  }).filter((r) => r.id && (r.more || r.share));
}

async function closeDialog() {
  const esc = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true };
  const x = document.querySelector('[role=dialog] button[aria-label*="close" i]');
  if (x) realClick(x);
  document.dispatchEvent(new KeyboardEvent('keydown', esc));
  await sleep(350);
  if (findByText('Copy Link')) {
    const dlg = document.querySelector('[role=dialog]');
    const xb = dlg && [...dlg.querySelectorAll('button')].find((b) => !norm(b.textContent));
    if (xb) realClick(xb);
    document.body.dispatchEvent(new KeyboardEvent('keydown', esc));
    await sleep(350);
  }
}

// return null jika sukses, atau string alasan gagal
async function grab(item) {
  const { row, more, share } = item;
  hover(row);
  await sleep(150);

  let opened = false;
  if (more) {
    realClick(more);
    const menu = await waitFor(() => document.querySelector('[role=menu]') ||
      (more.getAttribute('aria-expanded') === 'true' ? document.body : null), 2500);
    if (menu) {
      const scope = menu === document.body ? document : menu;
      const shareItem = await waitFor(() => findByText('Share', scope), 2000);
      if (shareItem) { realClick(shareItem.closest(CLICKABLE) || shareItem); opened = true; }
    }
  }
  if (!opened && share) { // cadangan: tombol Share langsung di baris
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
    await sleep(300);
    realClick(share);
    opened = true;
  }
  if (!opened) return 'Menu "More options" tidak terbuka / item Share tidak ketemu';

  const label = await waitFor(() => findByText('Copy Link'), 4000);
  if (!label) { await closeDialog(); return 'Dialog Share / "Copy Link" tidak muncul'; }

  // Susun daftar elemen yang akan dicoba diklik: label -> tombol pembungkus -> lingkaran biru -> semua ancestor
  const circle = label.parentElement && label.parentElement.querySelector('span.rounded-full');
  const chain = [];
  const push = (el) => { if (el && !chain.includes(el)) chain.push(el); };
  push(label.closest('.hxc-btn-base,button,[role=button],a'));
  push(circle);
  push(label);
  let up = label.parentElement, hops = 0;
  while (up && hops < 6 && !up.matches('[role=dialog]') && !(norm(up.textContent).includes('whatsapp'))) { push(up); up = up.parentElement; hops++; }

  fetchLinks = [];
  watch(true);
  const tryClick = (fn) => {
    const got = new Promise((r) => { waiter = r; setTimeout(() => { if (waiter === r) { waiter = null; r(null); } }, 1800); });
    fn();
    return got;
  };
  let url = null;
  for (const el of chain) {
    url = await tryClick(() => realClick(el));
    if (url) break;
    url = await tryClick(() => el.click());
    if (url) break;
  }
  watch(false);

  if (!url && [...new Set(fetchLinks)].length === 1) {
    url = fetchLinks[0]; await addLink(url);
  }
  if (!url) { // cadangan: cari link di dalam dialog (href tombol WhatsApp/Facebook/X/Email, input, dll.)
    const box = up || document.querySelector('[role=dialog]') || document.body;
    const texts = [...box.querySelectorAll('a[href],input,textarea,[data-url],[data-href]')].map(
      (e) => (e.href || e.value || e.dataset.url || e.dataset.href || '')
    );
    for (const t of texts) {
      let d = t; try { d = decodeURIComponent(t); } catch (e) {}
      const m = d.match(RE);
      if (m) { url = m[0]; await addLink(url); break; }
    }
  }
  if (!url) {
    try {
      const t = await navigator.clipboard.readText();
      const m = t.match(RE);
      if (m) { url = m[0]; await addLink(url); }
    } catch (e) { log('readText gagal:', e.message); }
  }
  await closeDialog();
  return url ? null : 'Copy Link diklik tapi link suno.com/s/... tidak tertangkap';
}

function scroller() {
  return document.querySelector('.clip-browser-list-scroller') || document.scrollingElement;
}

const allRows = () => [...document.querySelectorAll('.clip-row')];
const placeholders = () => allRows().filter((r) => !r.querySelector('a[href^="/song/"]'));

// Scroll agar placeholder / baris berikutnya ter-load
async function loadMore() {
  const ph = placeholders();
  if (ph.length) {
    ph[0].scrollIntoView({ block: 'center' });
  } else {
    const rows = allRows();
    if (rows.length) rows[rows.length - 1].scrollIntoView({ block: 'end' });
    const trig = document.querySelector('.intersection-trigger');
    if (trig) trig.scrollIntoView({ block: 'end' });
  }
  const s = scroller();
  s.scrollBy(0, Math.max(300, s.clientHeight * 0.5));
  await sleep(1500);
}

async function run(testOnly = false) {
  if (running) return;
  running = true; stopFlag = false;
  const done = new Set();
  let stall = 0, fail = 0, lastReason = '';
  let prevRows = -1, prevPh = -1, finished = false;
  await setProgress(0, 0);
  await setStatus(`Ditemukan ${getRows().length} lagu di layar`);
  await sleep(600);

  while (!stopFlag) {
    const items = getRows().filter((r) => !done.has(r.id));

    if (items.length) {
      stall = 0;
      for (const it of items) {
        if (stopFlag) break;
        done.add(it.id);
        it.row.scrollIntoView({ block: 'center' });
        await sleep(400);
        const fresh = getRows().find((r) => r.id === it.id) || it;
        const reason = await grab(fresh);
        if (reason) { fail++; lastReason = reason; }
        await setProgress(done.size, fail);
        await setStatus(`Berjalan... ${done.size} lagu diproses, ${(await getLinks()).length} link, gagal ${fail}${lastReason ? ' | ' + lastReason : ''}`);
        if (testOnly) { stopFlag = true; break; }
        await sleep(600);
      }
      prevRows = -1; prevPh = -1; // paksa cek ulang setelah batch selesai
      continue;
    }

    // Tidak ada lagu baru: cek apakah daftar masih bertambah / masih memuat
    const rowsNow = allRows().length, phNow = placeholders().length;
    const changed = rowsNow !== prevRows || phNow !== prevPh;
    prevRows = rowsNow; prevPh = phNow;
    stall = changed ? 0 : stall + 1;

    const s = scroller();
    const atBottom = s.scrollTop + s.clientHeight >= s.scrollHeight - 8;
    // Selesai jika daftar tidak berubah beberapa kali berturut-turut
    if (stall >= 4 || (atBottom && phNow === 0 && stall >= 2)) { finished = true; break; }

    await setProgress(done.size, fail);
    await setStatus(`Memeriksa lagu berikutnya... ${done.size} diproses, ${(await getLinks()).length} link, gagal ${fail}`);
    await loadMore();
  }

  running = false;
  const total = (await getLinks()).length;
  await setProgress(done.size, fail);
  if (testOnly) await setStatus(`Tes selesai. ${total} link tersimpan.`);
  else if (finished) await setStatus(`\u2705 Selesai! ${done.size} lagu diproses, ${total} link tersimpan, gagal ${fail}. Tekan Download TXT.`);
  else await setStatus(`Dihentikan. ${done.size} lagu diproses, ${total} link tersimpan, gagal ${fail}.`);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.cmd === 'start') run(false);
  if (msg.cmd === 'test') run(true);
  if (msg.cmd === 'stop') stopFlag = true;
  if (msg.cmd === 'toggle' && window.__sunoPanel) window.__sunoPanel.toggle();
});
log('content script aktif');


// ====================== PANEL MELAYANG ======================
(function buildPanel() {
  if (document.getElementById('suno-grabber-host')) return;
  const host = document.createElement('div');
  host.id = 'suno-grabber-host';
  host.style.cssText = 'all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    :host{all:initial}
    .wrap{font:13px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#ece9ff}
    .panel{width:330px;background:linear-gradient(180deg,#191433 0%,#0e0c1b 100%);border:1px solid #2f2a5c;border-radius:18px;
      box-shadow:0 24px 70px rgba(0,0,0,.6),0 0 0 1px rgba(139,92,246,.12),0 0 40px rgba(139,92,246,.12);overflow:hidden}
    .head{display:flex;align-items:center;gap:10px;padding:12px 12px 12px 14px;cursor:grab;user-select:none;
      background:linear-gradient(135deg,rgba(124,58,237,.35),rgba(236,72,153,.22));border-bottom:1px solid #2f2a5c}
    .head:active{cursor:grabbing}
    .logo{width:30px;height:30px;border-radius:9px;background:linear-gradient(135deg,#6d28d9,#ec4899);display:grid;place-items:center;flex:none;box-shadow:0 4px 14px rgba(236,72,153,.35)}
    .ttl{flex:1;min-width:0}
    .ttl b{display:block;font-size:14px;letter-spacing:.2px}
    .ttl span{display:block;font-size:11px;color:#a49fd4}
    .ib{all:unset;width:26px;height:26px;border-radius:8px;display:grid;place-items:center;cursor:pointer;color:#cfc9ff;font-size:15px;line-height:1}
    .ib:hover{background:rgba(255,255,255,.1)}
    .body{padding:14px;display:flex;flex-direction:column;gap:12px}
    .stats{display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:8px}
    .stat{background:#17132c;border:1px solid #2a2650;border-radius:12px;padding:9px 10px}
    .stat em{display:block;font-style:normal;font-weight:800;font-size:20px;color:#fff}
    .stat.big em{font-size:26px;background:linear-gradient(135deg,#a78bfa,#f472b6);-webkit-background-clip:text;background-clip:text;color:transparent}
    .stat span{font-size:11px;color:#8f8ab8}
    .stat.err em{color:#fb7185}
    .bar{height:7px;background:#1d1838;border-radius:99px;overflow:hidden;border:1px solid #2a2650}
    .bar i{display:block;height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,#8b5cf6,#ec4899);transition:width .4s ease}
    .bar.run i{background-size:200% 100%;animation:mv 1.4s linear infinite;background-image:linear-gradient(90deg,#8b5cf6,#ec4899,#8b5cf6)}
    @keyframes mv{to{background-position:-200% 0}}
    .status{font-size:12px;color:#b9b4e6;min-height:34px;background:#120f24;border:1px dashed #2f2a5c;border-radius:10px;padding:8px 10px;word-break:break-word}
    .row{display:flex;gap:8px}
    button.b{all:unset;box-sizing:border-box;flex:1;text-align:center;padding:9px 8px;border-radius:11px;font-weight:700;font-size:12.5px;cursor:pointer;
      border:1px solid transparent;transition:transform .08s,filter .15s,opacity .15s}
    button.b:hover{filter:brightness(1.12)}button.b:active{transform:scale(.97)}
    button.b[disabled]{opacity:.4;pointer-events:none}
    .primary{background:linear-gradient(135deg,#7c3aed,#ec4899);color:#fff;box-shadow:0 6px 18px rgba(236,72,153,.28)}
    .ghost{background:#1b1736;border-color:#2f2a5c;color:#d9d5ff}
    .danger{background:rgba(251,113,133,.14);border-color:rgba(251,113,133,.45);color:#fda4af}
    .ok{background:rgba(52,211,153,.14);border-color:rgba(52,211,153,.45);color:#6ee7b7}
    .list{max-height:140px;overflow:auto;background:#0b0918;border:1px solid #2a2650;border-radius:12px;padding:6px 4px;
      font:11.5px/1.7 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;color:#c4bfff}
    .list div{padding:0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .list div:hover{background:rgba(139,92,246,.15)}
    .list .n{color:#6f69a3;margin-right:6px}
    .list .empty{color:#6f69a3;text-align:center;padding:12px}
    .list::-webkit-scrollbar{width:8px}.list::-webkit-scrollbar-thumb{background:#2f2a5c;border-radius:9px}
    .note{font-size:10.5px;color:#7d78ad;text-align:center}
    .pill{display:none;align-items:center;gap:8px;cursor:pointer;padding:8px 14px 8px 8px;border-radius:99px;background:linear-gradient(135deg,#191433,#0e0c1b);
      border:1px solid #2f2a5c;box-shadow:0 12px 36px rgba(0,0,0,.55),0 0 24px rgba(139,92,246,.2);user-select:none}
    .pill b{font-size:13px}.pill .dot{width:8px;height:8px;border-radius:50%;background:#6f69a3}
    .pill.run .dot{background:#34d399;box-shadow:0 0 10px #34d399}
    .min .panel{display:none}.min .pill{display:flex}
  </style>
  <div class="wrap" id="wrap">
    <div class="panel">
      <div class="head" id="drag">
        <div class="logo"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07l1.1-1.1"/></svg></div>
        <div class="ttl"><b>Link Grabber</b><span>Suno share links</span></div>
        <button class="ib" id="min" title="Kecilkan">&#8211;</button>
        <button class="ib" id="hide" title="Sembunyikan (klik ikon ekstensi untuk menampilkan)">&#10005;</button>
      </div>
      <div class="body">
        <div class="stats">
          <div class="stat big"><em id="nLinks">0</em><span>Link tersimpan</span></div>
          <div class="stat"><em id="nDone">0</em><span>Diproses</span></div>
          <div class="stat err"><em id="nFail">0</em><span>Gagal</span></div>
        </div>
        <div class="bar" id="barWrap"><i id="bar"></i></div>
        <div class="status" id="status">Siap. Buka daftar lagu lalu tekan Mulai.</div>
        <div class="row">
          <button class="b primary" id="start">&#9654; Mulai</button>
          <button class="b ghost" id="test">Tes 1 lagu</button>
          <button class="b danger" id="stop">&#9632; Stop</button>
        </div>
        <div class="list" id="list"></div>
        <div class="row">
          <button class="b ok" id="dl">&#11015; Download TXT</button>
          <button class="b ghost" id="copy">Salin</button>
          <button class="b ghost" id="clear">Hapus</button>
        </div>
        <div class="note">Panel bisa digeser. Tidak perlu diklik saat proses berjalan.</div>
      </div>
    </div>
    <div class="pill" id="pill"><div class="logo" style="width:26px;height:26px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07l1.1-1.1"/></svg></div><b id="pillTxt">0 link</b><span class="dot"></span></div>
  </div>`;
  document.documentElement.appendChild(host);
  const $ = (id) => root.getElementById(id);

  async function render() {
    const { links = [], status, progress, ui } = await chrome.storage.local.get(['links', 'status', 'progress', 'ui']);
    $('nLinks').textContent = links.length;
    const p = progress || { done: 0, fail: 0, total: 0 };
    $('nDone').textContent = p.done;
    $('nFail').textContent = p.fail;
    $('status').textContent = status || 'Siap. Buka daftar lagu lalu tekan Mulai.';
    $('bar').style.width = (p.total ? Math.min(100, Math.round((p.done / p.total) * 100)) : 0) + '%';
    $('barWrap').classList.toggle('run', running);
    $('start').disabled = running; $('test').disabled = running; $('stop').disabled = !running;
    const list = $('list');
    list.innerHTML = '';
    if (!links.length) { const e = document.createElement('div'); e.className = 'empty'; e.textContent = 'Belum ada link'; list.appendChild(e); }
    links.forEach((l, i) => {
      const d = document.createElement('div');
      d.innerHTML = '<span class="n"></span><span class="u"></span>';
      d.querySelector('.n').textContent = String(i + 1).padStart(2, '0');
      d.querySelector('.u').textContent = l;
      list.appendChild(d);
    });
    list.scrollTop = list.scrollHeight;
    $('pillTxt').textContent = links.length + ' link' + (running ? ' • berjalan' : '');
    $('pill').classList.toggle('run', running);
    $('wrap').classList.toggle('min', !!(ui && ui.min));
  }

  async function setUi(patch) {
    const { ui = {} } = await chrome.storage.local.get('ui');
    await chrome.storage.local.set({ ui: { ...ui, ...patch } });
  }

  $('start').onclick = () => { chrome.storage.local.set({ status: 'Memulai...' }); run(false); };
  $('test').onclick = () => { chrome.storage.local.set({ status: 'Tes...' }); run(true); };
  $('stop').onclick = () => { stopFlag = true; chrome.storage.local.set({ status: 'Menghentikan...' }); };
  $('clear').onclick = async () => {
    await chrome.storage.local.set({ links: [], progress: { done: 0, fail: 0, total: 0 }, status: 'Daftar dihapus.' });
  };
  $('dl').onclick = async () => {
    const links = await getLinks();
    if (!links.length) { await setStatus('Belum ada link untuk di-download.'); return; }
    const blob = new Blob([links.join('\n') + '\n'], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'suno-share-links.txt';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };
  $('copy').onclick = async () => {
    const links = await getLinks();
    try { await navigator.clipboard.writeText(links.join('\n')); await setStatus(`${links.length} link disalin ke clipboard.`); }
    catch (e) { await setStatus('Gagal menyalin ke clipboard.'); }
  };
  $('min').onclick = () => setUi({ min: true });
  $('pill').onclick = (e) => { if (!pillDragged) setUi({ min: false }); };
  $('hide').onclick = () => { host.style.display = 'none'; };

  // geser panel (header atau pill)
  let pillDragged = false;
  function makeDraggable(handle, ignoreButtons) {
    let sx, sy, ox, oy, moving = false;
    handle.addEventListener('pointerdown', (e) => {
      if (ignoreButtons && e.target.closest('button')) return;
      const r = host.getBoundingClientRect();
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; moving = true; pillDragged = false;
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', (e) => {
      if (!moving) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) + Math.abs(dy) > 4) pillDragged = true;
      host.style.right = 'auto'; host.style.bottom = 'auto';
      host.style.left = Math.max(0, Math.min(window.innerWidth - 60, ox + dx)) + 'px';
      host.style.top = Math.max(0, Math.min(window.innerHeight - 40, oy + dy)) + 'px';
    });
    handle.addEventListener('pointerup', () => { moving = false; setTimeout(() => { pillDragged = false; }, 50); });
  }
  makeDraggable($('drag'), true);
  makeDraggable($('pill'), false);

  chrome.storage.onChanged.addListener(render);
  render();

  window.__sunoPanel = {
    toggle() { host.style.display = host.style.display === 'none' ? '' : 'none'; }
  };
})();
