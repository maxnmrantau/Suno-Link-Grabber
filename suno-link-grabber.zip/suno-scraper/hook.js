// Berjalan di konteks halaman (MAIN world)
(() => {
  const RX = /https?:\/\/(?:www\.)?suno\.com\/s\/[A-Za-z0-9_-]+/;
  const emit = (t, type = '__suno_copy') => {
    try { window.dispatchEvent(new CustomEvent(type, { detail: String(t) })); } catch (e) {}
  };
  // 1) Tangkap teks yang di-copy ke clipboard
  try {
    const p = Clipboard.prototype;
    const orig = p.writeText;
    p.writeText = function (t) { emit(t); return orig.call(this, t); };
  } catch (e) {}
  try {
    const oe = document.execCommand.bind(document);
    document.execCommand = function (c, ...a) {
      if (c === 'copy') {
        const s = String(getSelection());
        if (s) emit(s);
        const ae = document.activeElement;
        if (ae && ae.value) emit(ae.value);
      }
      return oe(c, ...a);
    };
  } catch (e) {}
  document.addEventListener('copy', () => {
    const s = String(getSelection());
    if (s) emit(s);
  }, true);

  // 2) Cadangan: pantau respons fetch yang berisi link share (hanya saat mode "watch" aktif)
  let watch = false;
  window.addEventListener('__suno_watch', (e) => { watch = e.detail === 'on'; });
  try {
    const of = window.fetch;
    window.fetch = function (...a) {
      const p = of.apply(this, a);
      if (watch) {
        p.then((r) => {
          try {
            r.clone().text().then((t) => {
              const m = t.match(RX);
              if (m) emit(m[0], '__suno_fetch');
            }).catch(() => {});
          } catch (e) {}
        }).catch(() => {});
      }
      return p;
    };
  } catch (e) {}
})();
