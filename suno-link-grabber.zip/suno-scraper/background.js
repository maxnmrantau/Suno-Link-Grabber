// Klik ikon ekstensi = tampilkan/sembunyikan panel melayang di halaman Suno (tanpa popup, jadi proses tidak terganggu)
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.tabs.sendMessage(tab.id, { cmd: 'toggle' }).catch(() => {});
});
